param([string]$Serial = 'emulator-5554')
$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
if ($Serial -notmatch '^emulator-\d+$') { throw 'Run this regression only on a disposable emulator.' }
$adb = Join-Path $PWD '.tools\platform-tools\platform-tools\adb.exe'
function Adb { & $adb -s $Serial @args; if ($LASTEXITCODE -ne 0) { throw "adb failed: $args" } }
New-Item -ItemType Directory -Force build\startup-test | Out-Null
Adb shell input keyevent 82
Adb install -r dist\Xingji-1.0.0.apk
Adb logcat -c
Adb shell am start -W -n cn.journey.garage/.MainActivity
Start-Sleep -Seconds 5
$oldLog = Adb logcat -d -b crash
$oldLog | Set-Content build\startup-test\old-crash.txt
if (($oldLog -join "`n") -notmatch 'NullPointerException') { throw 'Old null-pointer startup failure was not reproduced.' }
Adb install -r dist\Xingji-1.0.1.apk
Adb logcat -c
1..3 | ForEach-Object {
    Adb shell am force-stop cn.journey.garage
    Adb shell am start -W -n cn.journey.garage/.MainActivity
    Start-Sleep -Seconds 5
    $appPid = Adb shell pidof cn.journey.garage
    if (!$appPid) { throw 'App process did not survive launch.' }
}
$newLog = Adb logcat -d -b crash
$newLog | Set-Content build\startup-test\new-crash.txt
if (($newLog -join "`n") -match 'cn.journey.garage') { throw 'New APK still has a fatal crash.' }
Adb shell uiautomator dump /sdcard/xingji-window.xml
Adb pull /sdcard/xingji-window.xml build\startup-test\window.xml
if ((Get-Content build\startup-test\window.xml -Raw) -notmatch '添加车辆') { throw 'App survived but welcome UI was not rendered.' }
Adb shell screencap -p /sdcard/xingji-startup.png
Adb pull /sdcard/xingji-startup.png dist\Android启动验证.png
Write-Output 'PASS: reproduced old NPE, same-signature upgrade, 3 cold launches, WebView welcome UI, no app crash.'
