const {chromium}=require('playwright');
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const file=path.join(assets,req.url==='/'?'index.html':req.url);try{res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html');res.end(fs.readFileSync(file));}catch{res.writeHead(404);res.end();}});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 try{
 const page=await browser.newPage({viewport:{width:412,height:860},deviceScaleFactor:2,isMobile:true,hasTouch:true});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:'+server.address().port);
 const click=action=>page.locator(`[data-action="${action}"]`).last().click();
 await click('add-vehicle');await page.locator('[name=name]').fill('沃尔沃 XC60');await page.locator('[name=plate]').fill('沪 A · 60023');await page.locator('button[type=submit]').click();
 async function fuel(odo,liters,full,date,cost){await click('add-fuel');await page.locator('[name=odo]').fill(String(odo));await page.locator('[name=liters]').fill(String(liters));await page.locator('[name=date]').fill(date);await page.locator('[name=cost]').fill(String(cost));await page.locator('[name=full]').setChecked(full);await page.locator('button[type=submit]').click();}
 await fuel(12000,45,true,'2026-07-01',340);await fuel(12300,20,false,'2026-07-08',150);await fuel(12600,25,true,'2026-07-15',185);
 assert.match(await page.locator('.value').innerText(),/7.50/);
 await fuel(13100,38,true,'2026-07-25',285);await fuel(13650,39,true,'2026-08-05',290);await fuel(14200,36,true,'2026-08-16',270);await fuel(14700,35,true,'2026-08-25',265);await fuel(15200,32,true,'2026-09-06',240);
 await click('add-service');await page.locator('[name=odo]').fill('15000');await page.locator('[name=date]').fill('2026-09-01');await page.locator('[data-action=chip]').filter({hasText:'机油'}).first().click();await page.locator('[name=cost]').fill('580');await page.locator('button[type=submit]').click();
 fs.mkdirSync(path.resolve(__dirname,'../dist'),{recursive:true});
 // Native insets are supplied in CSS pixels. Exercise both navigation modes and IME.
 assert.equal(await page.locator('[data-action=settings]').count(),1);
 const layoutResults=[];
 for(const [width,height,bottom] of [[412,860,24],[412,860,48],[384,800,24],[384,800,48],[360,760,48]]){
   await page.setViewportSize({width,height});
   await page.evaluate(b=>{applySystemInsets(b,false);window.scrollTo(0,0);document.querySelector('#toast').classList.remove('show');},bottom);
   const geometry=await page.evaluate(()=>{
     const rect=s=>document.querySelector(s).getBoundingClientRect();
     return {quickTop:rect('.quick-actions').top,quickBottom:rect('.quick-actions').bottom,recentBottom:rect('.recent-card').bottom,navTop:rect('.nav').top,navButtonBottom:rect('.nav button').bottom,scrollHeight:document.documentElement.scrollHeight,height:innerHeight};
   });
   layoutResults.push({width,height,bottom,...geometry});
   assert.ok(geometry.quickTop>=0&&geometry.quickBottom<240,'Quick actions immediately visible');
   assert.ok(geometry.recentBottom<=geometry.navTop,JSON.stringify({width,height,bottom,...geometry}));
   assert.ok(geometry.navButtonBottom<=height-bottom,'Controls avoid system navigation');
   assert.ok(geometry.scrollHeight<=height+1,JSON.stringify({width,height,bottom,...geometry}));
   await page.screenshot({path:path.resolve(__dirname,`../dist/首页-${width}-${bottom===48?'三键':'手势'}.png`)});
 }
 console.log('LAYOUT',JSON.stringify(layoutResults));
 await page.setViewportSize({width:384,height:460});
 await page.evaluate(()=>applySystemInsets(0,true));
 await click('add-fuel');
 assert.equal(await page.locator('.nav').isVisible(),false);
 await page.locator('[name=note]').fill('键盘安全区测试');
 await page.locator('button[type=submit]').scrollIntoViewIfNeeded();
 assert.ok((await page.locator('button[type=submit]').boundingBox()).y<460);
 await click('close');
 await page.setViewportSize({width:412,height:860});await page.evaluate(()=>applySystemInsets(24,false));
 await page.screenshot({path:path.resolve(__dirname,'../dist/总览预览.png'),fullPage:true});
 await click('history');await page.locator('[data-action=edit-fuel]').first().click();await page.locator('[name=liters]').fill('30');await page.locator('button[type=submit]').click();
 assert.match(await page.locator('.record').first().innerText(),/30.00 L/);
 await page.screenshot({path:path.resolve(__dirname,'../dist/记录预览.png'),fullPage:true});
 await click('garage');await click('add-vehicle');await page.locator('[name=name]').fill('本田 CB400');await page.locator('[name=type]').selectOption('motorcycle');assert.match(await page.locator('[name=items]').inputValue(),/链条/);await page.locator('button[type=submit]').click();
 await click('home');assert.match(await page.locator('.value').innerText(),/—/);assert.equal(await page.locator('.record').count(),0);
 await fuel(8000,12,true,'2026-08-01',100);await fuel(8300,10,true,'2026-08-10',80);assert.match(await page.locator('.value').innerText(),/3.33/);
 await click('pick');await page.locator('[data-action=switch]').filter({hasText:'沃尔沃'}).click();assert.notEqual(await page.locator('.value').innerText(),'3.33');
 const backup=await page.evaluate(()=>localStorage.getItem('xingji'));
 await page.reload();assert.equal(await page.locator('.record').count(),2);
 await page.evaluate(raw=>receiveBackup(raw),backup);await click('confirm');assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('xingji')).vehicles.length),2);
 const before=await page.evaluate(()=>localStorage.getItem('xingji'));await page.evaluate(()=>receiveBackup('{"version":9}'));assert.equal(await page.evaluate(()=>localStorage.getItem('xingji')),before);
 await click('history');await page.locator('[data-action=edit-fuel]').first().click();await page.locator('[name=odo]').fill('14700');await page.locator('button[type=submit]').click();assert.match(await page.locator('#form-error').innerText(),/已有加油记录/);await click('close');
 await page.locator('[data-action=edit-fuel]').first().click();await click('delete-record');await click('confirm');
 assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('xingji')).fuel.length),9);
 await page.setViewportSize({width:360,height:740});await click('home');assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
 await page.setViewportSize({width:800,height:380});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
 assert.deepEqual(errors,[]);console.log('PASS: UI create/edit/delete, partial fuel, car/motorcycle isolation, persistence, backup validation/restore, responsive 360/412/800px; no JS errors.');
 }finally{await browser.close();server.close();}
})().catch(e=>{console.error(e);server.close();process.exitCode=1;});
