# 行记 · Journey Journal

离线管理多辆汽车与摩托车的加油、油耗和保养记录。Android 13+，无需账号、网络权限或 Google Play 服务。

**[下载 v1.1.0 APK](https://github.com/FlypigLee/xingji/releases/tag/v1.1.0)** · [更新内容](#110-首页与系统导航优化)

<img src="docs/home-preview.png" width="360" alt="行记首页：快捷加油保养、油耗趋势和最近记录" />

*截图使用演示数据及模拟导航安全区，首次安装不附带示例车辆。*

## 1.1.0 首页与系统导航优化

- 加油与保养快捷按钮移至车辆选择下方，进入首页即可操作，点击区域至少 48px。
- 品牌栏压缩为单行；仅保留底部设置入口。平均油耗、最新里程、加油支出合并为一张摘要卡。
- 趋势筛选与标题合并，缩短图表；首页展示最近两笔动态，全部历史仍在「记录」页。
- 按窗口高度调整留白及卡片。默认字号、典型记录的 412×860、384×800 手势/三键安全区，以及 360×760 三键安全区均通过一屏几何验证。长内容、大字体、横屏仍允许自然滚动，不裁剪页面。
- 原生 WindowInsets 提供底部实际安全区，背景延伸至透明系统导航栏。关闭三键导航的系统对比度遮罩，使用浅底深色系统按钮。键盘单独缩减可用区域，弹出时隐藏应用底部导航。保留 1.0.1 的挂载后初始化和空值保护。
- 已通过功能回归、布局/键盘模拟、算法测试及签名/对齐校验。安全区截图是 Chromium 模拟，不是三星系统导航实机截图；新版导航效果仍需手机验证。

当前安装包：`dist/Xingji-1.1.0.apk`，版本号 3，使用原签名覆盖安装即可保留数据。

## 1.0.1 启动修复

修正 `MainActivity.onCreate` 在 `setContentView` 之前直接调用 `Window.getInsetsController()` 的初始化顺序。Android 13 的 `PhoneWindow` 实现会直接访问尚未创建的 `mDecor`，可能触发空指针异常。改为视图挂载后的回调中读取控制器，并检查空值。版本号提升至 1.0.1 / versionCode 2，保留包名、签名及数据文件格式，可覆盖升级。

本次构建、签名/对齐校验、9 项算法测试及浏览器 UI 回归已通过。原生回归脚本 `tests/android-startup.ps1` 已准备，但本机缺少可用模拟器加速驱动，软件模式未成功启动，故原生启动回归尚未执行通过；也未连接三星真机。不要将浏览器测试等同于真机验证。

面向中国大陆版三星 Galaxy S23 Ultra 的离线车辆油耗与保养记录应用。支持 Android 13 及以上；使用 Android 17 SDK 37.2 稳定平台包编译，targetSdkVersion 37。无需 Google Play 服务、账号或联网权限。

## 安装

将 `dist/Xingji-1.1.0.apk` 传到手机，在「我的文件」中点击安装，按系统提示为该来源允许安装应用。新安装不含任何示例车辆，预览图片中的数据仅用于测试。

首次启动添加汽车或摩托车。所有记录、统计与保养快捷项按车辆隔离。保养项目可在「车库 → 车辆设置」中逐行配置。

## 油耗规则

- 使用里程表累计读数，单位 km；加油量单位 L。
- 第一次加满建立基准；下次加满结算区间。
- 区间油量包含中途所有未加满记录及结束时的加满记录，不含开始基准的加油量。
- 油耗 = 区间累计油量 / 两次加满里程差 × 100。
- 平均油耗为总有效油量 / 总有效里程 × 100，非各区间油耗的简单算术平均。
- 首次加满前、末次加满后的未闭合区间不参与平均值。
- 编辑、补录、删除、恢复备份都会重新生成统计，不缓存派生值。
- 不支持里程表回拨/更换；必须保持同一车辆加油日期和累计里程顺序一致。相同里程不能有两笔加油。

## 备份

「设置 → 导出完整备份」使用 Android 系统文件选择器输出 JSON。「从文件恢复」会先验证车辆归属、字段、日期和里程，再显示记录数量并要求确认覆盖。数据采用 AtomicFile 保存至应用内部目录。没有云同步；卸载会清除本地数据，请先导出。

## 架构与构建

原生 Java Activity + 随 APK 分发的本地 WebView UI；无远程页面、无 JS CDN、无第三方运行依赖。应用使用系统 WebView（Samsung / Android System WebView），不要求谷歌框架。`https://app.local` 仅为本地资源拦截域名，所有外部请求被拒绝，Manifest 未申请 INTERNET 权限。

原生层负责 edge-to-edge 系统栏 / 刘海 / 键盘 Insets、Android 13 返回手势、原子文件写入和 Storage Access Framework 备份导入导出。UI 为触屏响应式布局，支持文字缩放，表单和图表具备可访问性标签。

构建不依赖 Gradle/Maven 下载：使用官方 Android Build Tools 的 aapt2、D8、zipalign、apksigner 生成标准签名 APK。

```powershell
# 将 JDK 21 解压到 .tools/jdk/<jdk-directory>
# SDK 平台放到 .tools/platform/android-37.2
# Build Tools 放到 .tools/build-tools/android-37.0
./build.ps1
# 或传入自定义位置
./build.ps1 -JavaHome C:/jdk-21 -SdkPlatform C:/Android/Sdk/platforms/android-37.2 -BuildTools C:/Android/Sdk/build-tools/37.0.0
node --test tests/core.test.cjs
# 设置 NODE_PATH 指向安装了 playwright 的 node_modules 后：
node tests/ui.test.cjs
```

`signing/` 保存本机生成的发布签名和密码，已被 Git 忽略。请自行妥善备份，后续覆盖升级必须使用同一签名。不要将私钥或密码分享或提交到公开仓库。打包产物为 release 签名、非 debuggable APK。

## 验证边界

已做纯函数油耗/备份测试与 Chromium 自动化 UI 测试，包括加油、编辑、删除、汽车/摩托车数据隔离、刷新持久化、备份校验与恢复、360/412/800px 布局。构建后校验 APK 签名和 ZIP 对齐。浏览器测试不能替代三星实机上的 WebView、文件选择器与系统手势测试；当前未连接 S23 Ultra 真机。

SDK 依据：[Android 17 设置文档](https://developer.android.com/about/versions/17/setup-sdk) 和 [Google SDK 官方仓库元数据](https://dl.google.com/android/repository/repository2-3.xml)。
