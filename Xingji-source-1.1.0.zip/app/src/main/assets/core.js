(function(root){
  'use strict';
  const presets={car:['机油','机油滤芯','空气滤芯','空调滤芯','刹车油','冷却液','火花塞','轮胎'],motorcycle:['机油','机油滤芯','空气滤芯','链条清洁润滑','链条 / 齿盘','刹车油','冷却液','轮胎']};
  function calculate(records){
    const list=[...records].sort((a,b)=>a.odo-b.odo||a.date.localeCompare(b.date));
    let anchor=null, liters=0; const points=[];
    for(const r of list){
      if(anchor){liters+=r.liters;if(r.full){const distance=r.odo-anchor.odo;if(distance>0)points.push({id:r.id,date:r.date,odo:r.odo,distance,liters,rate:liters/distance*100,from:anchor.date});anchor=r;liters=0;}}
      else if(r.full)anchor=r;
    }
    const distance=points.reduce((s,p)=>s+p.distance,0),fuel=points.reduce((s,p)=>s+p.liters,0);
    return {points,average:distance?fuel/distance*100:null,distance,fuel,pending:liters};
  }
  function validDate(v){return typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&!isNaN(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v;}
  function validate(s){
    const fail=()=>{throw Error('文件格式或记录数据不正确，未导入');};
    const str=(v,max)=>typeof v==='string'&&v.length<=max;
    const num=(v,max,positive=false)=>Number.isFinite(v)&&v>=0&&v<=max&&(!positive||v>0);
    if(!s||s.version!==1||!Array.isArray(s.vehicles)||!Array.isArray(s.fuel)||!Array.isArray(s.service))fail();
    if(s.vehicles.length>200||s.fuel.length+s.service.length>50000)fail();
    const ids=new Set();const unique=id=>{if(!str(id,100)||!id||ids.has(id))fail();ids.add(id);};
    for(const v of s.vehicles){unique(v.id);if(!str(v.name,60)||!v.name.trim()||!['car','motorcycle'].includes(v.type)||!str(v.plate,30)||!Array.isArray(v.items)||v.items.length>50||v.items.some(x=>!str(x,60)||!x.trim())||new Set(v.items).size!==v.items.length)fail();}
    const vehicles=new Set(s.vehicles.map(v=>v.id));
    for(const [kind,rows] of [['fuel',s.fuel],['service',s.service]])for(const r of rows){
      unique(r.id);if(!vehicles.has(r.vehicle)||!validDate(r.date)||!num(r.odo,9999999)||!num(r.cost,9999999)||!str(r.note,1000))fail();
      if(kind==='fuel'&&(!num(r.liters,9999,true)||typeof r.full!=='boolean'))fail();
      if(kind==='service'&&(!Array.isArray(r.items)||!r.items.length||r.items.length>50||r.items.some(x=>!str(x,60)||!x.trim())))fail();
    }
    for(const v of s.vehicles){const rows=s.fuel.filter(r=>r.vehicle===v.id).sort((a,b)=>a.odo-b.odo);for(let i=1;i<rows.length;i++)if(rows[i].odo===rows[i-1].odo||rows[i].date<rows[i-1].date)fail();}
    return s;
  }
  const api={presets,calculate,validate,validDate};
  if(typeof module!=='undefined')module.exports=api;else root.Garage=api;
})(typeof window==='undefined'?globalThis:window);
