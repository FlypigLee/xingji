package cn.journey.garage;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.util.AtomicFile;
import android.view.*;
import android.webkit.*;
import android.widget.FrameLayout;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private AtomicFile data;
    private String exportData;
    private volatile int safeBottomDp;
    private volatile boolean keyboardVisible;
    private static final int EXPORT=41, IMPORT=42;
    private static final int LIMIT=8*1024*1024;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        data=new AtomicFile(new File(getFilesDir(),"garage.json"));
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarContrastEnforced(false);
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(246,245,240));
        root.setOnApplyWindowInsetsListener((v,insets)->{
            android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
            android.graphics.Insets ime=insets.getInsets(WindowInsets.Type.ime());
            keyboardVisible=insets.isVisible(WindowInsets.Type.ime());
            safeBottomDp=keyboardVisible?0:Math.round(bars.bottom/getResources().getDisplayMetrics().density);
            // Extend the WebView background under system navigation, but keep controls above it.
            // Only the keyboard reduces the native viewport; bottom bar safety is applied in CSS.
            v.setPadding(bars.left,bars.top,bars.right,keyboardVisible?ime.bottom:0);
            dispatchInsets();
            return WindowInsets.CONSUMED;
        });
        web=new WebView(this);
        web.setBackgroundColor(Color.rgb(246,245,240));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(),"Native");
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view,String url){dispatchInsets();}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
                Uri u=req.getUrl();
                if("app.local".equals(u.getHost()) && "https".equals(u.getScheme())){
                    String p=u.getPath(); if(p==null||p.equals("/"))p="/index.html";
                    if(!p.matches("/[a-zA-Z0-9._-]+"))return blocked();
                    try { return new WebResourceResponse(p.endsWith(".js")?"application/javascript":p.endsWith(".css")?"text/css":"text/html","UTF-8",getAssets().open(p.substring(1))); }catch(IOException e){return blocked();}
                } return blocked();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}
        });
        root.addView(web,new FrameLayout.LayoutParams(-1,-1)); setContentView(root);
        // PhoneWindow's decor and the view's controller may not exist during onCreate.
        // Configure bars only after attachment, never dereference the early controller.
        root.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){
            @Override public void onViewAttachedToWindow(View view){
                WindowInsetsController controller=view.getWindowInsetsController();
                if(controller!=null){
                    int lightBars=WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            |WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    controller.setSystemBarsAppearance(lightBars,lightBars);
                }
                view.requestApplyInsets();
                view.removeOnAttachStateChangeListener(this);
            }
            @Override public void onViewDetachedFromWindow(View view){}
        });
        web.loadUrl("https://app.local/index.html");
        getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0,()->web.evaluateJavascript("window.handleBack()",null));
    }
    private void dispatchInsets(){
        if(web!=null)web.evaluateJavascript("window.applySystemInsets && window.applySystemInsets("
                +safeBottomDp+","+keyboardVisible+")",null);
    }
    private WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));}
    private String read(InputStream in)throws IOException {
        try(InputStream s=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192]; int n; while((n=s.read(b))!=-1){if(out.size()+n>LIMIT)throw new IOException("备份超过 8 MB 上限");out.write(b,0,n);}return out.toString("UTF-8");
        }
    }
    private void callback(String name,String value){runOnUiThread(()->web.evaluateJavascript("window."+name+"("+JSONObject.quote(value)+")",null));}
    public class Bridge {
        @JavascriptInterface public int bottomInset(){return safeBottomDp;}
        @JavascriptInterface public synchronized String load(){try{return read(data.openRead());}catch(FileNotFoundException e){return "";}catch(Exception e){return "!READ_ERROR";}}
        @JavascriptInterface public synchronized String save(String json){
            FileOutputStream out=null;
            try {if(json.getBytes(StandardCharsets.UTF_8).length>LIMIT)throw new IOException();new JSONObject(json);out=data.startWrite();out.write(json.getBytes(StandardCharsets.UTF_8));data.finishWrite(out);return "ok";}catch(Exception e){if(out!=null)data.failWrite(out);return "保存失败，请检查可用存储空间";}
        }
        @JavascriptInterface public void exportBackup(String json){exportData=json;runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"行记备份-"+java.time.LocalDate.now()+".json");startActivityForResult(i,EXPORT);});}
        @JavascriptInterface public void importBackup(){runOnUiThread(()->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),IMPORT));}
        @JavascriptInterface public void exit(){runOnUiThread(()->finish());}
    }
    @Override protected void onActivityResult(int request,int result,Intent intent){
        super.onActivityResult(request,result,intent);
        if(result!=RESULT_OK||intent==null||intent.getData()==null)return;
        try {
            if(request==EXPORT){try(OutputStream out=getContentResolver().openOutputStream(intent.getData(),"wt")){if(out==null)throw new IOException();out.write(exportData.getBytes(StandardCharsets.UTF_8));}callback("notifyUser","备份已导出");}
            if(request==IMPORT)callback("receiveBackup",read(getContentResolver().openInputStream(intent.getData())));
        } catch(Exception e){callback("notifyUser","文件操作失败，请重新选择文件或保存位置");}
    }
    @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("Native");web.destroy();}super.onDestroy();}
}
