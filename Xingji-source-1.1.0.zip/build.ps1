param([string]$JavaHome, [string]$SdkPlatform, [string]$BuildTools)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (!$JavaHome) { $JavaHome = (Get-ChildItem "$PSScriptRoot\.tools\jdk" -Directory | Select-Object -First 1).FullName }
if (!$SdkPlatform) { $SdkPlatform = "$PSScriptRoot\.tools\platform\android-37.2" }
if (!$BuildTools) { $BuildTools = "$PSScriptRoot\.tools\build-tools\android-37.0" }
$env:JAVA_HOME = $JavaHome
$env:PATH = "$JavaHome\bin;$env:PATH"
function Checked { param([string]$Exe,[string[]]$Arguments) & $Exe @Arguments; if ($LASTEXITCODE -ne 0) { throw "Build step failed: $Exe" } }
New-Item -ItemType Directory -Force build,build\classes,build\dex,build\gen,dist,signing | Out-Null
Checked "$BuildTools\aapt2.exe" @('compile','--dir','app\src\main\res','-o','build\resources.zip')
Checked "$BuildTools\aapt2.exe" @('link','-o','build\base.apk','-I',"$SdkPlatform\android.jar",'--manifest','app\src\main\AndroidManifest.xml','--java','build\gen','--min-sdk-version','33','--target-sdk-version','37','-A','app\src\main\assets','build\resources.zip')
$sources = @(Get-ChildItem app\src\main\java,build\gen -Recurse -Filter *.java | ForEach-Object FullName)
Checked "$JavaHome\bin\javac.exe" (@('-encoding','UTF-8','-source','17','-target','17','-classpath',"$SdkPlatform\android.jar",'-d','build\classes') + $sources)
$classes = @(Get-ChildItem build\classes -Recurse -Filter *.class | ForEach-Object FullName)
Checked "$JavaHome\bin\java.exe" (@('-cp',"$BuildTools\lib\d8.jar",'com.android.tools.r8.D8','--release','--min-api','33','--lib',"$SdkPlatform\android.jar",'--output','build\dex') + $classes)
Copy-Item build\base.apk build\unsigned.apk -Force
Checked "$JavaHome\bin\jar.exe" @('uf','build\unsigned.apk','-C','build\dex','classes.dex')
Checked "$BuildTools\zipalign.exe" @('-f','-p','4','build\unsigned.apk','build\aligned.apk')
# The local signing identity is retained for compatible future updates; never commit it.
if (!(Test-Path signing\release.p12)) {
    $bytes = [byte[]]::new(32)
    [System.Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
    $password = [Convert]::ToBase64String($bytes)
    [System.IO.File]::WriteAllText("$PSScriptRoot\signing\password.txt",$password)
    $env:XINGJI_SIGNING_PASSWORD = $password
    Checked "$JavaHome\bin\keytool.exe" @('-genkeypair','-keystore','signing\release.p12','-storetype','PKCS12','-storepass:env','XINGJI_SIGNING_PASSWORD','-alias','xingji','-keyalg','RSA','-keysize','3072','-validity','10000','-dname','CN=Xingji Local Release, O=Journey Journal, C=CN')
}
$env:XINGJI_SIGNING_PASSWORD = [System.IO.File]::ReadAllText("$PSScriptRoot\signing\password.txt")
try {
    Checked "$JavaHome\bin\java.exe" @('-jar',"$BuildTools\lib\apksigner.jar",'sign','--ks','signing\release.p12','--ks-key-alias','xingji','--ks-pass','env:XINGJI_SIGNING_PASSWORD','--out','dist\Xingji-1.1.0.apk','build\aligned.apk')
} finally { Remove-Item Env:XINGJI_SIGNING_PASSWORD -ErrorAction SilentlyContinue }
Checked "$JavaHome\bin\java.exe" @('-jar',"$BuildTools\lib\apksigner.jar",'verify','--verbose','--print-certs','dist\Xingji-1.1.0.apk')
Checked "$BuildTools\zipalign.exe" @('-c','-v','4','dist\Xingji-1.1.0.apk')
Get-FileHash dist\Xingji-1.1.0.apk -Algorithm SHA256 | Format-List
